export const SERVER_URL = "";
export const IMG_URL = "http://192.168.0.144:5224";
