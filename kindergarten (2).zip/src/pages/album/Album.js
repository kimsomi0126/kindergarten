import React, { useEffect, useState } from "react";
import ReadAllAlbum from "../../components/album/ReadAllAlbum";
import {
  getIndParentList,
  getIndTeacherList,
} from "../../api/individualNotice/indivNoticeApi";
import useCustomLogin from "../../hooks/useCustomLogin";
import { useNavigate, useSearchParams } from "react-router-dom";
export const API_SERVER_HOST = "";
const host = `${API_SERVER_HOST}/api/album/listall`;
import ModalOneBtn from "../../components/ui/ModalOneBtn";

const Album = () => {
  const navigate = useNavigate();
  const { isLogin, isParentLogin } = useCustomLogin();
  const [isOpen, setIsOpen] = useState(false);
  const [title, setTitle] = useState("");
  const [subTitle, setSubTitle] = useState("");

  useEffect(() => {
    if (!isLogin && !isParentLogin) {
      // 로그인하지 않았을 경우
      setIsOpen(true);
      setTitle("회원 전용 페이지");
      setSubTitle("로그인 회원만 접근 가능합니다.");
    }
  }, [isLogin, isParentLogin]);

  const handleOk = () => {
    setIsOpen(false);
    if (!isLogin && !isParentLogin) {
      navigate("/login"); // 로그인 페이지로 이동
    }
  };

  return (
    <>
      <ModalOneBtn
        isOpen={isOpen}
        handleOk={handleOk}
        title={title}
        subTitle={subTitle}
      />
      <ReadAllAlbum />;
    </>
  );
};

export default Album;
