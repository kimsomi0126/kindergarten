export const SERVER_URL = "";
export const IMG_URL = "http://112.222.157.156:5224";
