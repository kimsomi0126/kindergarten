export const getNum = (체크, 기본) => {
  if (!체크) {
    return 기본;
  }
  return 체크;
};
